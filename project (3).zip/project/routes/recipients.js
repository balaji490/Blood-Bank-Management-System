const express = require('express');
const router = express.Router();
const Recipient = require('../models/Recipient');

// Get all recipients
router.get('/', async (req, res) => {
  try {
    const recipients = await Recipient.find().sort({ requestedDate: -1 });
    res.json(recipients);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get recipient by ID
router.get('/:id', async (req, res) => {
  try {
    const recipient = await Recipient.findById(req.params.id);
    if (!recipient) {
      return res.status(404).json({ message: 'Recipient not found' });
    }
    res.json(recipient);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create new recipient request
router.post('/', async (req, res) => {
  const recipient = new Recipient(req.body);
  
  try {
    const newRecipient = await recipient.save();
    res.status(201).json(newRecipient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update recipient request
router.put('/:id', async (req, res) => {
  try {
    const recipient = await Recipient.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!recipient) {
      return res.status(404).json({ message: 'Recipient not found' });
    }
    res.json(recipient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete recipient request
router.delete('/:id', async (req, res) => {
  try {
    const recipient = await Recipient.findByIdAndDelete(req.params.id);
    if (!recipient) {
      return res.status(404).json({ message: 'Recipient not found' });
    }
    res.json({ message: 'Recipient request deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get requests by status
router.get('/status/:status', async (req, res) => {
  try {
    const recipients = await Recipient.find({ status: req.params.status });
    res.json(recipients);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get urgent requests
router.get('/urgent/requests', async (req, res) => {
  try {
    const urgentRequests = await Recipient.find({
      urgency: { $in: ['Urgent', 'Emergency'] },
      status: { $in: ['Pending', 'Processing'] }
    }).sort({ requiredDate: 1 });
    res.json(urgentRequests);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update request status
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const recipient = await Recipient.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    if (!recipient) {
      return res.status(404).json({ message: 'Recipient not found' });
    }
    res.json(recipient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router; 