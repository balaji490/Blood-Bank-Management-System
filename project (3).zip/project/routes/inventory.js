const express = require('express');
const router = express.Router();
const Inventory = require('../models/Inventory');

// Get all inventory
router.get('/', async (req, res) => {
  try {
    const inventory = await Inventory.find().sort({ bloodType: 1 });
    res.json(inventory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get inventory by blood type
router.get('/:bloodType', async (req, res) => {
  try {
    const inventory = await Inventory.findOne({ bloodType: req.params.bloodType });
    if (!inventory) {
      return res.status(404).json({ message: 'Inventory not found for this blood type' });
    }
    res.json(inventory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create new inventory entry
router.post('/', async (req, res) => {
  try {
    const existingInventory = await Inventory.findOne({ bloodType: req.body.bloodType });
    if (existingInventory) {
      return res.status(400).json({ message: 'Inventory for this blood type already exists' });
    }
    
    const inventory = new Inventory(req.body);
    const newInventory = await inventory.save();
    res.status(201).json(newInventory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update inventory
router.put('/:bloodType', async (req, res) => {
  try {
    const inventory = await Inventory.findOneAndUpdate(
      { bloodType: req.params.bloodType },
      req.body,
      { new: true, runValidators: true }
    );
    if (!inventory) {
      return res.status(404).json({ message: 'Inventory not found' });
    }
    res.json(inventory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Add blood units
router.patch('/:bloodType/add', async (req, res) => {
  try {
    const { units } = req.body;
    const inventory = await Inventory.findOne({ bloodType: req.params.bloodType });
    
    if (!inventory) {
      return res.status(404).json({ message: 'Inventory not found' });
    }
    
    inventory.totalUnits += units;
    inventory.availableUnits += units;
    await inventory.save();
    
    res.json(inventory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Remove blood units
router.patch('/:bloodType/remove', async (req, res) => {
  try {
    const { units } = req.body;
    const inventory = await Inventory.findOne({ bloodType: req.params.bloodType });
    
    if (!inventory) {
      return res.status(404).json({ message: 'Inventory not found' });
    }
    
    if (inventory.availableUnits < units) {
      return res.status(400).json({ message: 'Insufficient blood units available' });
    }
    
    inventory.totalUnits -= units;
    inventory.availableUnits -= units;
    await inventory.save();
    
    res.json(inventory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Reserve blood units
router.patch('/:bloodType/reserve', async (req, res) => {
  try {
    const { units } = req.body;
    const inventory = await Inventory.findOne({ bloodType: req.params.bloodType });
    
    if (!inventory) {
      return res.status(404).json({ message: 'Inventory not found' });
    }
    
    if (inventory.availableUnits < units) {
      return res.status(400).json({ message: 'Insufficient blood units available' });
    }
    
    inventory.availableUnits -= units;
    inventory.reservedUnits += units;
    await inventory.save();
    
    res.json(inventory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get critical inventory
router.get('/status/critical', async (req, res) => {
  try {
    const criticalInventory = await Inventory.find({ status: 'Critical' });
    res.json(criticalInventory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get low inventory
router.get('/status/low', async (req, res) => {
  try {
    const lowInventory = await Inventory.find({ 
      status: { $in: ['Critical', 'Low'] } 
    });
    res.json(lowInventory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Initialize inventory for all blood types
router.post('/initialize', async (req, res) => {
  try {
    const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    const inventoryData = [];
    
    for (const bloodType of bloodTypes) {
      const existing = await Inventory.findOne({ bloodType });
      if (!existing) {
        inventoryData.push({
          bloodType,
          totalUnits: 0,
          availableUnits: 0,
          reservedUnits: 0,
          expiredUnits: 0,
          minimumThreshold: 10,
          maximumCapacity: 100
        });
      }
    }
    
    if (inventoryData.length > 0) {
      const newInventory = await Inventory.insertMany(inventoryData);
      res.status(201).json(newInventory);
    } else {
      res.json({ message: 'All inventory entries already exist' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router; 