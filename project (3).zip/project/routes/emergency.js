const express = require('express');
const router = express.Router();
const Emergency = require('../models/Emergency');
const Donor = require('../models/Donor');

// Get all emergency requests
router.get('/', async (req, res) => {
  try {
    const emergencies = await Emergency.find()
      .populate('assignedDonors.donorId', 'name phone bloodType')
      .sort({ requestedDate: -1 });
    res.json(emergencies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get emergency by ID
router.get('/:id', async (req, res) => {
  try {
    const emergency = await Emergency.findById(req.params.id)
      .populate('assignedDonors.donorId', 'name phone bloodType');
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    res.json(emergency);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create new emergency request
router.post('/', async (req, res) => {
  const emergency = new Emergency(req.body);
  
  try {
    const newEmergency = await emergency.save();
    res.status(201).json(newEmergency);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update emergency request
router.put('/:id', async (req, res) => {
  try {
    const emergency = await Emergency.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    res.json(emergency);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete emergency request
router.delete('/:id', async (req, res) => {
  try {
    const emergency = await Emergency.findByIdAndDelete(req.params.id);
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    res.json({ message: 'Emergency request deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get emergency requests by status
router.get('/status/:status', async (req, res) => {
  try {
    const emergencies = await Emergency.find({ status: req.params.status })
      .populate('assignedDonors.donorId', 'name phone bloodType');
    res.json(emergencies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get critical emergency requests
router.get('/urgency/critical', async (req, res) => {
  try {
    const criticalEmergencies = await Emergency.find({
      urgency: 'Critical',
      status: { $in: ['Pending', 'Processing'] }
    }).populate('assignedDonors.donorId', 'name phone bloodType');
    res.json(criticalEmergencies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Assign donors to emergency request
router.post('/:id/assign-donors', async (req, res) => {
  try {
    const { donorIds } = req.body;
    const emergency = await Emergency.findById(req.params.id);
    
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    
    // Clear existing assignments
    emergency.assignedDonors = [];
    
    // Add new assignments
    for (const donorId of donorIds) {
      emergency.assignedDonors.push({
        donorId,
        status: 'Contacted'
      });
    }
    
    emergency.status = 'Processing';
    await emergency.save();
    
    const populatedEmergency = await Emergency.findById(req.params.id)
      .populate('assignedDonors.donorId', 'name phone bloodType');
    
    res.json(populatedEmergency);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update donor assignment status
router.patch('/:id/donor-status/:donorId', async (req, res) => {
  try {
    const { status } = req.body;
    const emergency = await Emergency.findById(req.params.id);
    
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    
    const assignment = emergency.assignedDonors.find(
      a => a.donorId.toString() === req.params.donorId
    );
    
    if (!assignment) {
      return res.status(404).json({ message: 'Donor assignment not found' });
    }
    
    assignment.status = status;
    await emergency.save();
    
    const populatedEmergency = await Emergency.findById(req.params.id)
      .populate('assignedDonors.donorId', 'name phone bloodType');
    
    res.json(populatedEmergency);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Find available donors for emergency
router.get('/:id/find-donors', async (req, res) => {
  try {
    const emergency = await Emergency.findById(req.params.id);
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    
    const availableDonors = await Donor.find({
      bloodType: emergency.bloodType,
      isAvailable: true,
      healthStatus: 'Eligible'
    }).select('name phone bloodType lastDonation');
    
    res.json(availableDonors);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update emergency status
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const emergency = await Emergency.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    ).populate('assignedDonors.donorId', 'name phone bloodType');
    
    if (!emergency) {
      return res.status(404).json({ message: 'Emergency request not found' });
    }
    
    res.json(emergency);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router; 