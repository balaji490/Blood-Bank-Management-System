# Blood Bank Management System

A comprehensive web-based blood bank management system built with Node.js, Express.js, MongoDB, and modern frontend technologies.

## Features

### 🏥 Core Functionality
- **Donor Management**: Register, track, and manage blood donors
- **Blood Inventory**: Real-time tracking of blood stock levels
- **Blood Requests**: Handle regular blood requests from hospitals
- **Emergency Requests**: Priority handling for urgent blood needs
- **Dashboard**: Real-time overview of system status

### 🎨 User Interface
- **Modern Design**: Clean, responsive interface with intuitive navigation
- **Real-time Updates**: Live data updates without page refresh
- **Mobile Responsive**: Works seamlessly on all devices
- **Interactive Modals**: Easy form submissions and data entry
- **Toast Notifications**: User-friendly feedback system

### 🔧 Technical Features
- **RESTful API**: Complete backend API with MongoDB integration
- **Data Validation**: Server-side validation for all inputs
- **Error Handling**: Comprehensive error handling and user feedback
- **Auto-refresh**: Automatic data updates every 30 seconds
- **Status Tracking**: Real-time status updates for all operations

## Technology Stack

### Backend
- **Node.js**: JavaScript runtime environment
- **Express.js**: Web application framework
- **MongoDB**: NoSQL database with Mongoose ODM
- **CORS**: Cross-origin resource sharing
- **Body Parser**: Request body parsing middleware

### Frontend
- **HTML5**: Semantic markup
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Vanilla JavaScript with async/await
- **Font Awesome**: Icon library
- **Responsive Design**: Mobile-first approach

## Prerequisites

Before running this application, make sure you have the following installed:

- **Node.js** (v14 or higher)
- **MongoDB** (v4.4 or higher)
- **npm** or **yarn** package manager

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd blood-bank-management-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start MongoDB**
   Make sure MongoDB is running on your system:
   ```bash
   # On Windows
   net start MongoDB
   
   # On macOS/Linux
   sudo systemctl start mongod
   ```

4. **Initialize the database**
   The system will automatically create the necessary collections when you first run it.

5. **Start the application**
   ```bash
   npm start
   ```

6. **Access the application**
   Open your browser and navigate to `http://localhost:3000`

## Development

To run the application in development mode with auto-restart:

```bash
npm run dev
```

## Project Structure

```
blood-bank-management-system/
├── models/                 # MongoDB schemas
│   ├── Donor.js           # Donor model
│   ├── Recipient.js       # Blood request model
│   ├── Inventory.js       # Blood inventory model
│   └── Emergency.js       # Emergency request model
├── routes/                # API routes
│   ├── donors.js          # Donor management endpoints
│   ├── recipients.js      # Blood request endpoints
│   ├── inventory.js       # Inventory management endpoints
│   └── emergency.js       # Emergency request endpoints
├── public/                # Frontend files
│   ├── index.html         # Main HTML file
│   ├── styles.css         # CSS styles
│   └── script.js          # Frontend JavaScript
├── server.js              # Main server file
├── package.json           # Dependencies and scripts
└── README.md              # Project documentation
```

## API Endpoints

### Donors
- `GET /api/donors` - Get all donors
- `GET /api/donors/:id` - Get donor by ID
- `POST /api/donors` - Register new donor
- `PUT /api/donors/:id` - Update donor
- `DELETE /api/donors/:id` - Delete donor
- `GET /api/donors/blood-type/:bloodType` - Get donors by blood type
- `GET /api/donors/available/status` - Get available donors

### Recipients (Blood Requests)
- `GET /api/recipients` - Get all requests
- `GET /api/recipients/:id` - Get request by ID
- `POST /api/recipients` - Create new request
- `PUT /api/recipients/:id` - Update request
- `DELETE /api/recipients/:id` - Delete request
- `GET /api/recipients/status/:status` - Get requests by status
- `GET /api/recipients/urgent/requests` - Get urgent requests
- `PATCH /api/recipients/:id/status` - Update request status

### Inventory
- `GET /api/inventory` - Get all inventory
- `GET /api/inventory/:bloodType` - Get inventory by blood type
- `POST /api/inventory` - Create inventory entry
- `PUT /api/inventory/:bloodType` - Update inventory
- `PATCH /api/inventory/:bloodType/add` - Add blood units
- `PATCH /api/inventory/:bloodType/remove` - Remove blood units
- `PATCH /api/inventory/:bloodType/reserve` - Reserve blood units
- `GET /api/inventory/status/critical` - Get critical inventory
- `GET /api/inventory/status/low` - Get low inventory
- `POST /api/inventory/initialize` - Initialize inventory for all blood types

### Emergency Requests
- `GET /api/emergency` - Get all emergency requests
- `GET /api/emergency/:id` - Get emergency by ID
- `POST /api/emergency` - Create emergency request
- `PUT /api/emergency/:id` - Update emergency request
- `DELETE /api/emergency/:id` - Delete emergency request
- `GET /api/emergency/status/:status` - Get emergencies by status
- `GET /api/emergency/urgency/critical` - Get critical emergencies
- `POST /api/emergency/:id/assign-donors` - Assign donors to emergency
- `PATCH /api/emergency/:id/donor-status/:donorId` - Update donor assignment status
- `GET /api/emergency/:id/find-donors` - Find available donors for emergency
- `PATCH /api/emergency/:id/status` - Update emergency status

## Usage Guide

### 1. Dashboard Overview
- View total blood units, active donors, pending requests, and critical stock levels
- Real-time updates every 30 seconds

### 2. Donor Management
- Register new donors with complete information
- View all registered donors in a table format
- Track donor health status and last donation date
- Delete donors when needed

### 3. Blood Inventory
- View current stock levels for all blood types
- Color-coded status indicators (Good, Low, Critical)
- Real-time percentage calculations
- Track reserved and available units

### 4. Blood Requests
- Submit regular blood requests from hospitals
- Specify patient details, blood type, and urgency
- Track request status (Pending, Approved, Rejected, Completed)
- Manage request lifecycle

### 5. Emergency Requests
- Submit urgent blood requests with priority levels
- Assign donors to emergency requests
- Track emergency status and donor responses
- Handle critical situations efficiently

## Database Schema

### Donor Schema
```javascript
{
  name: String (required),
  email: String (required, unique),
  phone: String (required),
  bloodType: String (enum: A+, A-, B+, B-, AB+, AB-, O+, O-),
  age: Number (18-65),
  gender: String (enum: Male, Female, Other),
  address: Object,
  lastDonation: Date,
  isAvailable: Boolean,
  healthStatus: String (enum: Eligible, Ineligible, Pending),
  emergencyContact: Object,
  createdAt: Date,
  updatedAt: Date
}
```

### Recipient Schema
```javascript
{
  name: String (required),
  email: String (required),
  phone: String (required),
  bloodType: String (required),
  units: Number (1-10),
  urgency: String (enum: Normal, Urgent, Emergency),
  hospital: String (required),
  doctor: String (required),
  reason: String (required),
  status: String (enum: Pending, Approved, Rejected, Completed),
  requestedDate: Date,
  requiredDate: Date (required),
  notes: String,
  createdAt: Date,
  updatedAt: Date
}
```

### Inventory Schema
```javascript
{
  bloodType: String (required),
  totalUnits: Number,
  availableUnits: Number,
  reservedUnits: Number,
  expiredUnits: Number,
  lastUpdated: Date,
  minimumThreshold: Number,
  maximumCapacity: Number,
  status: String (enum: Critical, Low, Normal, Good)
}
```

### Emergency Schema
```javascript
{
  requesterName: String (required),
  requesterPhone: String (required),
  patientName: String (required),
  bloodType: String (required),
  units: Number (1-20),
  hospital: String (required),
  doctor: String (required),
  urgency: String (enum: Critical, Very Urgent, Urgent),
  reason: String (required),
  status: String (enum: Pending, Processing, Approved, Rejected, Completed),
  requestedDate: Date,
  requiredDate: Date (required),
  notes: String,
  assignedDonors: Array,
  createdAt: Date,
  updatedAt: Date
}
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please contact the development team or create an issue in the repository.

## Future Enhancements

- [ ] User authentication and authorization
- [ ] Advanced reporting and analytics
- [ ] Email notifications
- [ ] SMS alerts for emergencies
- [ ] Blood compatibility checking
- [ ] Donor appointment scheduling
- [ ] Integration with hospital systems
- [ ] Mobile application
- [ ] Multi-language support
- [ ] Advanced search and filtering 