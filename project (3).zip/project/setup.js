const mongoose = require('mongoose');
const Inventory = require('./models/Inventory');

// Connect to MongoDB
mongoose.connect('mongodb+srv://jayanthilluru:WLólkGlFpNY8bK41@cluster0.7vm5364.mongodb.net/blood_bank?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected for setup...'))
.catch(err => console.error('MongoDB connection error:', err));

// Initialize inventory with sample data
async function initializeInventory() {
    try {
        const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
        
        for (const bloodType of bloodTypes) {
            const existing = await Inventory.findOne({ bloodType });
            if (!existing) {
                const inventory = new Inventory({
                    bloodType,
                    totalUnits: Math.floor(Math.random() * 50) + 20,
                    availableUnits: Math.floor(Math.random() * 40) + 15,
                    reservedUnits: Math.floor(Math.random() * 10),
                    expiredUnits: 0,
                    minimumThreshold: 10,
                    maximumCapacity: 100
                });
                await inventory.save();
                console.log(`Created inventory for ${bloodType}`);
            } else {
                console.log(`Inventory for ${bloodType} already exists`);
            }
        }
        
        console.log('Inventory initialization completed!');
        process.exit(0);
    } catch (error) {
        console.error('Error initializing inventory:', error);
        process.exit(1);
    }
}

// Run the setup
initializeInventory(); 