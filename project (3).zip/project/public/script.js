// API Base URL
const API_BASE_URL = 'http://localhost:3000/api';

// Global variables
let donors = [];
let recipients = [];
let emergencies = [];
let inventory = [];

// DOM Elements
const loadingSpinner = document.getElementById('loadingSpinner');
const toastContainer = document.getElementById('toastContainer');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    setupMobileMenu();
});

// Initialize the application
async function initializeApp() {
    showLoading();
    try {
        await Promise.all([
            loadDashboardData(),
            loadInventory(),
            loadDonors(),
            loadRecipients(),
            loadEmergencies()
        ]);
    } catch (error) {
        showToast('Error loading data: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

// Setup event listeners
function setupEventListeners() {
    // Form submissions
    document.getElementById('donorForm').addEventListener('submit', handleDonorSubmit);
    document.getElementById('requestForm').addEventListener('submit', handleRequestSubmit);
    document.getElementById('emergencyForm').addEventListener('submit', handleEmergencySubmit);

    // Modal close events
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
}

// Setup mobile menu
function setupMobileMenu() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
}

// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.getElementById(modalId).querySelector('form').reset();
}

// Loading functions
function showLoading() {
    loadingSpinner.style.display = 'block';
}

function hideLoading() {
    loadingSpinner.style.display = 'none';
}

// Toast notification functions
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = document.createElement('i');
    icon.className = getToastIcon(type);
    
    const text = document.createElement('span');
    text.textContent = message;
    
    toast.appendChild(icon);
    toast.appendChild(text);
    toastContainer.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

function getToastIcon(type) {
    switch(type) {
        case 'success': return 'fas fa-check-circle';
        case 'error': return 'fas fa-exclamation-circle';
        case 'warning': return 'fas fa-exclamation-triangle';
        default: return 'fas fa-info-circle';
    }
}

// API functions
async function apiCall(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        },
    };
    
    const response = await fetch(url, { ...defaultOptions, ...options });
    
    if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'API request failed');
    }
    
    return response.json();
}

// Dashboard functions
async function loadDashboardData() {
    try {
        const [inventoryData, donorsData, recipientsData] = await Promise.all([
            apiCall('/inventory'),
            apiCall('/donors/available/status'),
            apiCall('/recipients/status/Pending')
        ]);
        
        updateDashboard(inventoryData, donorsData, recipientsData);
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

function updateDashboard(inventoryData, donorsData, recipientsData) {
    const totalUnits = inventoryData.reduce((sum, item) => sum + item.availableUnits, 0);
    const criticalStock = inventoryData.filter(item => item.status === 'Critical').length;
    
    document.getElementById('totalUnits').textContent = totalUnits;
    document.getElementById('activeDonors').textContent = donorsData.length;
    document.getElementById('pendingRequests').textContent = recipientsData.length;
    document.getElementById('criticalStock').textContent = criticalStock;
}

// Inventory functions
async function loadInventory() {
    try {
        inventory = await apiCall('/inventory');
        renderInventory();
    } catch (error) {
        console.error('Error loading inventory:', error);
    }
}

function renderInventory() {
    const inventoryGrid = document.getElementById('inventoryGrid');
    inventoryGrid.innerHTML = '';
    
    inventory.forEach(item => {
        const card = document.createElement('div');
        card.className = `inventory-card ${item.status.toLowerCase()}`;
        
        const percentage = Math.round((item.availableUnits / item.maximumCapacity) * 100);
        
        card.innerHTML = `
            <h3>${item.bloodType}</h3>
            <div class="status ${item.status.toLowerCase()}">Status: ${item.status}</div>
            <div class="units">Available: ${item.availableUnits}/${item.maximumCapacity} units (${percentage}%)</div>
            <div class="units">Reserved: ${item.reservedUnits} units</div>
            <div class="units">Last Updated: ${new Date(item.lastUpdated).toLocaleDateString()}</div>
        `;
        
        inventoryGrid.appendChild(card);
    });
}

// Donor functions
async function loadDonors() {
    try {
        donors = await apiCall('/donors');
        renderDonors();
    } catch (error) {
        console.error('Error loading donors:', error);
    }
}

function renderDonors() {
    const tbody = document.getElementById('donorsTableBody');
    tbody.innerHTML = '';
    
    donors.forEach(donor => {
        const row = document.createElement('tr');
        const lastDonation = donor.lastDonation ? new Date(donor.lastDonation).toLocaleDateString() : 'Never';
        
        row.innerHTML = `
            <td>${donor.name}</td>
            <td>${donor.bloodType}</td>
            <td>${donor.phone}</td>
            <td><span class="status-badge status-${donor.healthStatus.toLowerCase()}">${donor.healthStatus}</span></td>
            <td>${lastDonation}</td>
            <td>
                <button class="btn btn-secondary" onclick="editDonor('${donor._id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-emergency" onclick="deleteDonor('${donor._id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

async function handleDonorSubmit(event) {
    event.preventDefault();
    showLoading();
    
    try {
        const formData = new FormData(event.target);
        const donorData = Object.fromEntries(formData.entries());
        
        await apiCall('/donors', {
            method: 'POST',
            body: JSON.stringify(donorData)
        });
        
        showToast('Donor registered successfully!', 'success');
        closeModal('donorModal');
        await loadDonors();
        await loadDashboardData();
    } catch (error) {
        showToast('Error registering donor: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function deleteDonor(donorId) {
    if (!confirm('Are you sure you want to delete this donor?')) return;
    
    showLoading();
    try {
        await apiCall(`/donors/${donorId}`, { method: 'DELETE' });
        showToast('Donor deleted successfully!', 'success');
        await loadDonors();
        await loadDashboardData();
    } catch (error) {
        showToast('Error deleting donor: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

// Recipient functions
async function loadRecipients() {
    try {
        recipients = await apiCall('/recipients');
        renderRecipients();
    } catch (error) {
        console.error('Error loading recipients:', error);
    }
}

function renderRecipients() {
    const tbody = document.getElementById('requestsTableBody');
    tbody.innerHTML = '';
    
    recipients.forEach(recipient => {
        const row = document.createElement('tr');
        const requiredDate = new Date(recipient.requiredDate).toLocaleDateString();
        
        row.innerHTML = `
            <td>${recipient.name}</td>
            <td>${recipient.bloodType}</td>
            <td>${recipient.units}</td>
            <td><span class="status-badge status-${recipient.urgency.toLowerCase()}">${recipient.urgency}</span></td>
            <td>${recipient.hospital}</td>
            <td><span class="status-badge status-${recipient.status.toLowerCase()}">${recipient.status}</span></td>
            <td>
                <button class="btn btn-primary" onclick="updateRequestStatus('${recipient._id}', 'Approved')">
                    <i class="fas fa-check"></i>
                </button>
                <button class="btn btn-secondary" onclick="updateRequestStatus('${recipient._id}', 'Rejected')">
                    <i class="fas fa-times"></i>
                </button>
                <button class="btn btn-emergency" onclick="deleteRequest('${recipient._id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

async function handleRequestSubmit(event) {
    event.preventDefault();
    showLoading();
    
    try {
        const formData = new FormData(event.target);
        const requestData = Object.fromEntries(formData.entries());
        
        await apiCall('/recipients', {
            method: 'POST',
            body: JSON.stringify(requestData)
        });
        
        showToast('Blood request submitted successfully!', 'success');
        closeModal('requestModal');
        await loadRecipients();
        await loadDashboardData();
    } catch (error) {
        showToast('Error submitting request: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function updateRequestStatus(requestId, status) {
    showLoading();
    try {
        await apiCall(`/recipients/${requestId}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status })
        });
        
        showToast(`Request ${status.toLowerCase()} successfully!`, 'success');
        await loadRecipients();
        await loadDashboardData();
    } catch (error) {
        showToast('Error updating request status: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function deleteRequest(requestId) {
    if (!confirm('Are you sure you want to delete this request?')) return;
    
    showLoading();
    try {
        await apiCall(`/recipients/${requestId}`, { method: 'DELETE' });
        showToast('Request deleted successfully!', 'success');
        await loadRecipients();
        await loadDashboardData();
    } catch (error) {
        showToast('Error deleting request: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

// Emergency functions
async function loadEmergencies() {
    try {
        emergencies = await apiCall('/emergency');
        renderEmergencies();
    } catch (error) {
        console.error('Error loading emergencies:', error);
    }
}

function renderEmergencies() {
    const tbody = document.getElementById('emergencyTableBody');
    tbody.innerHTML = '';
    
    emergencies.forEach(emergency => {
        const row = document.createElement('tr');
        const requiredDate = new Date(emergency.requiredDate).toLocaleDateString();
        
        row.innerHTML = `
            <td>${emergency.patientName}</td>
            <td>${emergency.bloodType}</td>
            <td>${emergency.units}</td>
            <td><span class="status-badge status-${emergency.urgency.toLowerCase()}">${emergency.urgency}</span></td>
            <td>${emergency.hospital}</td>
            <td><span class="status-badge status-${emergency.status.toLowerCase()}">${emergency.status}</span></td>
            <td>
                <button class="btn btn-primary" onclick="updateEmergencyStatus('${emergency._id}', 'Processing')">
                    <i class="fas fa-play"></i>
                </button>
                <button class="btn btn-secondary" onclick="updateEmergencyStatus('${emergency._id}', 'Completed')">
                    <i class="fas fa-check"></i>
                </button>
                <button class="btn btn-emergency" onclick="deleteEmergency('${emergency._id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

async function handleEmergencySubmit(event) {
    event.preventDefault();
    showLoading();
    
    try {
        const formData = new FormData(event.target);
        const emergencyData = Object.fromEntries(formData.entries());
        
        await apiCall('/emergency', {
            method: 'POST',
            body: JSON.stringify(emergencyData)
        });
        
        showToast('Emergency request submitted successfully!', 'success');
        closeModal('emergencyModal');
        await loadEmergencies();
        await loadDashboardData();
    } catch (error) {
        showToast('Error submitting emergency request: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function updateEmergencyStatus(emergencyId, status) {
    showLoading();
    try {
        await apiCall(`/emergency/${emergencyId}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status })
        });
        
        showToast(`Emergency request ${status.toLowerCase()} successfully!`, 'success');
        await loadEmergencies();
        await loadDashboardData();
    } catch (error) {
        showToast('Error updating emergency status: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

async function deleteEmergency(emergencyId) {
    if (!confirm('Are you sure you want to delete this emergency request?')) return;
    
    showLoading();
    try {
        await apiCall(`/emergency/${emergencyId}`, { method: 'DELETE' });
        showToast('Emergency request deleted successfully!', 'success');
        await loadEmergencies();
        await loadDashboardData();
    } catch (error) {
        showToast('Error deleting emergency request: ' + error.message, 'error');
    } finally {
        hideLoading();
    }
}

// Initialize inventory data
async function initializeInventory() {
    try {
        await apiCall('/inventory/initialize', { method: 'POST' });
        showToast('Inventory initialized successfully!', 'success');
        await loadInventory();
    } catch (error) {
        showToast('Error initializing inventory: ' + error.message, 'error');
    }
}

// Auto-refresh data every 30 seconds
setInterval(() => {
    loadDashboardData();
    loadInventory();
}, 30000);

// Export functions for global access
window.openModal = openModal;
window.closeModal = closeModal;
window.editDonor = function(donorId) {
    // TODO: Implement edit donor functionality
    showToast('Edit functionality coming soon!', 'info');
};
window.deleteDonor = deleteDonor;
window.updateRequestStatus = updateRequestStatus;
window.deleteRequest = deleteRequest;
window.updateEmergencyStatus = updateEmergencyStatus;
window.deleteEmergency = deleteEmergency;
window.initializeInventory = initializeInventory; 