const mongoose = require('mongoose');

const emergencySchema = new mongoose.Schema({
  requesterName: {
    type: String,
    required: true,
    trim: true
  },
  requesterPhone: {
    type: String,
    required: true
  },
  patientName: {
    type: String,
    required: true,
    trim: true
  },
  bloodType: {
    type: String,
    required: true,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
  },
  units: {
    type: Number,
    required: true,
    min: 1,
    max: 20
  },
  hospital: {
    type: String,
    required: true
  },
  doctor: {
    type: String,
    required: true
  },
  urgency: {
    type: String,
    enum: ['Critical', 'Very Urgent', 'Urgent'],
    default: 'Urgent'
  },
  reason: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['Pending', 'Processing', 'Approved', 'Rejected', 'Completed'],
    default: 'Pending'
  },
  requestedDate: {
    type: Date,
    default: Date.now
  },
  requiredDate: {
    type: Date,
    required: true
  },
  notes: String,
  assignedDonors: [{
    donorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Donor'
    },
    status: {
      type: String,
      enum: ['Contacted', 'Confirmed', 'Declined', 'Completed'],
      default: 'Contacted'
    }
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

emergencySchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Emergency', emergencySchema); 