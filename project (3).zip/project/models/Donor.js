const mongoose = require('mongoose');

const donorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  phone: {
    type: String,
    required: true,
    match: [/^\d{10}$/, 'Please enter a valid 10-digit phone number']
  },
  bloodType: {
    type: String,
    required: true,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
  },
  age: {
    type: Number,
    required: true,
    min: 18,
    max: 65
  },
  gender: {
    type: String,
    required: true,
    enum: ['Male', 'Female', 'Other']
  },
  address: {
    street: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    zipCode: { type: String, required: true, match: [/^\d{5,6}$/, 'Please enter a valid zip code'] }
  },
  lastDonation: {
    type: Date,
    default: null
  },
  isAvailable: {
    type: Boolean,
    default: true
  },
  healthStatus: {
    type: String,
    enum: ['Eligible', 'Ineligible', 'Pending'],
    default: 'Pending'
  },
  emergencyContact: {
    name: { type: String, required: true },
    phone: { type: String, required: true, match: [/^\d{10}$/, 'Please enter a valid 10-digit phone number'] },
    relationship: { type: String, required: true }
  }
}, { timestamps: true });

module.exports = mongoose.model('Donor', donorSchema);