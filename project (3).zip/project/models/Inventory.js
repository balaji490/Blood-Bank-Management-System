const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  bloodType: {
    type: String,
    required: true,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
  },
  totalUnits: {
    type: Number,
    required: true,
    default: 0,
    min: 0
  },
  availableUnits: {
    type: Number,
    required: true,
    default: 0,
    min: 0
  },
  reservedUnits: {
    type: Number,
    required: true,
    default: 0,
    min: 0
  },
  expiredUnits: {
    type: Number,
    required: true,
    default: 0,
    min: 0
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  minimumThreshold: {
    type: Number,
    required: true,
    default: 10
  },
  maximumCapacity: {
    type: Number,
    required: true,
    default: 100
  },
  status: {
    type: String,
    enum: ['Critical', 'Low', 'Normal', 'Good'],
    default: 'Normal'
  }
});

// Calculate status based on available units
inventorySchema.methods.updateStatus = function() {
  const percentage = (this.availableUnits / this.maximumCapacity) * 100;
  
  if (this.availableUnits <= this.minimumThreshold) {
    this.status = 'Critical';
  } else if (percentage <= 25) {
    this.status = 'Low';
  } else if (percentage <= 75) {
    this.status = 'Normal';
  } else {
    this.status = 'Good';
  }
};

inventorySchema.pre('save', function(next) {
  this.updateStatus();
  this.lastUpdated = Date.now();
  next();
});

module.exports = mongoose.model('Inventory', inventorySchema); 